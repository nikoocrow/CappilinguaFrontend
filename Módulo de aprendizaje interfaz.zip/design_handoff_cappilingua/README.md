# Handoff: Cappilingua — Módulo de aprendizaje (interfaz)

## Overview

Cappilingua es una app gamificada para aprender coreano explorando ciudades (Seúl como ciudad
principal, Bogotá bloqueada). El usuario avanza por un mapa isométrico de la ciudad, completa
misiones, aprende vocabulario, personaliza su personaje, compra artículos con wones (₩) y gemas,
y toma clases en vivo con profesores nativos.

Este paquete documenta **10 pantallas** de la vista del estudiante, con navegación completa entre
ellas y flujos funcionales (comprar, reservar, seguir, responder preguntas).

El render 3D de la ciudad y del personaje se hará con **three.js** en el proyecto real. En estos
prototipos ese canvas está representado con una **imagen de marcador de posición** (`assets/seoul-scene.png`).
Donde aparece esa imagen a pantalla completa, ahí va el canvas de three.js.

---

## About the Design Files

Los archivos incluidos son **referencias de diseño creadas en HTML** — prototipos que muestran la
apariencia y el comportamiento buscados, **no código de producción para copiar directamente**.

La tarea es **recrear estos diseños en el entorno existente del codebase destino** (React, Vue,
React Native, SwiftUI, etc.) usando sus patrones y librerías establecidos. Si el proyecto aún no
tiene un entorno, elegir el framework más apropiado e implementar los diseños ahí.

Notas técnicas sobre los prototipos:

- `Cappilingua.dc.html` está escrito con un runtime propietario de prototipado (`<x-dc>`, `<sc-for>`,
  `<sc-if>`, holes `{{ }}`). **No portar ese runtime.** Leerlo como especificación: la clase
  `Component` contiene los datos y la lógica, y el template contiene la estructura y los estilos.
- Todos los estilos son **inline** por requisitos del runtime de prototipado. En producción, usar
  el sistema de estilos del codebase (CSS Modules, Tailwind, styled-components, etc.).
- `Cappilingua - Prototipo.html` es la versión autocontenida (imágenes en base64) para abrir en
  el navegador sin servidor y ver el diseño funcionando. Útil como referencia visual viva.

---

## Fidelity

**Alta fidelidad (hifi).** Colores, tipografía, espaciado, radios, sombras y estados de interacción
son finales. Recrear la UI con fidelidad de píxel usando las librerías y patrones del codebase.

Excepción: los assets gráficos (escena de la ciudad, capibara, íconos de ítems) son recortes de
mockups de referencia, no assets finales de producción. Ver la sección **Assets**.

---

## Design Tokens

### Colores

| Token | Hex | Uso |
|---|---|---|
| `bg/base` | `#0b1120` | Fondo de la app |
| `bg/chrome` | `#0c1322` | Barra superior, barra lateral |
| `bg/panel` | `#0e1426` | Paneles, tarjetas grandes, modales |
| `bg/panel-alt` | `#0d1322` | Panel de personalización |
| `bg/input` | `#161d33` | Campos de formulario |
| `bg/capsule` | `#141c30` | Cápsulas de la barra superior (nivel, monedas) |
| `bg/stage` | `#070b15` | Fondo de la sala en vivo |
| `surface/1` | `rgba(255,255,255,.04)` | Tarjetas sobre fondo base |
| `surface/2` | `rgba(255,255,255,.045)` | Tarjetas (variante) |
| `surface/3` | `rgba(255,255,255,.06)` | Botones fantasma, hover |
| `border/hairline` | `rgba(255,255,255,.06)` | Separadores |
| `border/subtle` | `rgba(255,255,255,.08)` | Borde de tarjeta |
| `border/default` | `rgba(255,255,255,.1)` | Borde de input |
| `border/strong` | `rgba(255,255,255,.18)` | Botones de contorno |
| `text/primary` | `#eef1fb` | Texto principal |
| `text/secondary` | `#c3c9de` | Texto de apoyo |
| `text/tertiary` | `#9aa3bf` | Texto atenuado, etiquetas |
| `text/quaternary` | `#7a8298` | Micro-etiquetas, metadatos |
| `text/disabled` | `#6f7896` | Deshabilitado |
| `brand/purple` | `#7c3aed` | Primario (relleno de botón, activo) |
| `brand/purple-light` | `#9b6bff` | Inicio del degradado primario |
| `brand/purple-lighter` | `#b794ff` | Fin del degradado de progreso |
| `brand/lavender` | `#c4a6ff` | Íconos y texto de acento |
| `brand/lavender-text` | `#a78bff` | Enlaces, etiquetas de acento |
| `brand/purple-deep` | `#5a23b3` | Sombra sólida del botón (estilo B) |
| `accent/gold` | `#f5c451` | Estrellas, racha, marca de agua del logo |
| `accent/gold-dark` | `#f2a93a` | Fin del degradado del logo |
| `accent/gold-light` | `#ffd980` | Inicio del degradado del logo |
| `currency/won` | `#4fb3a8` | Ficha de wones (celadón coreano) |
| `currency/won-stroke` | `#2f8378` | Borde de la ficha de wones |
| `currency/won-ink` | `#06231f` | Glifo ₩ sobre la ficha |
| `currency/won-tint` | `rgba(79,179,168,.12)` | Fondo del saldo de wones |
| `currency/gem` | `#a87bff` | Relleno de la gema |
| `currency/gem-edge` | `#d3bcff` | Faceta de la gema |
| `status/live` | `#ef4444` | Insignia EN VIVO, botón de salir |
| `status/live-dark` | `#dc2626` | Fin del degradado de EN VIVO |
| `status/success` | `#22c55e` | Respuesta correcta, verificado |
| `status/success-light` | `#5ee08a` | Texto de éxito |
| `status/error` | `#ef4444` | Respuesta incorrecta |
| `status/error-light` | `#ff8585` | Texto de error |
| `pin/marker` | `#ef4d6d` | Pin de ubicación en el mapa |

Degradados clave:

- Primario: `linear-gradient(135deg,#9b6bff,#7c3aed)`
- Progreso XP: `linear-gradient(90deg,#7c3aed,#b794ff)`
- Progreso de recompensa: `linear-gradient(90deg,#ffd980,#f2a93a)`
- Logo (texto): `linear-gradient(180deg,#ffd980,#f2a93a)` con `background-clip:text`
- Banner de colaboración: `linear-gradient(110deg,#2a1a5e,#4322a3)`
- Pack de la tienda: `linear-gradient(110deg,#20183f,#3d2585)`
- Invitar y ganar: `linear-gradient(150deg,#7c3aed,#4322a3)`
- Nav activo: `linear-gradient(100deg, rgba(124,58,237,.4), rgba(124,58,237,.12))`

### Tipografía

Tres familias, cargadas desde Google Fonts:

| Familia | Pesos | Uso |
|---|---|---|
| **Baloo 2** | 500, 600, 700, 800 | Display gamificado: logo, títulos de pantalla, números (nivel, saldos, XP), etiquetas de botón |
| **Nunito** | 400, 600, 700, 800 + itálica 600 | Texto de UI: párrafos, etiquetas, inputs, metadatos |
| **Cormorant Garamond** | 400, 500, 600 + itálica 400 | Registro editorial: títulos y valores del panel de personalización y de la tienda |

Escala tipográfica observada (px):

`10` · `10.5` · `11` · `11.5` · `12` · `12.5` · `13` · `13.5` · `14` · `14.5` · `15` · `15.5` ·
`16` · `17` · `18` · `19` · `20` · `22` · `23` · `24` · `25` · `26` · `28` · `30` · `32` · `34` ·
`36` · `38` · `40` · `42` · `58`

Patrones tipográficos recurrentes:

- **Micro-etiqueta (versalitas)**: 10–11px, `font-weight:700`, `letter-spacing:2–3.2px`, `text-transform:uppercase`, color `text/quaternary`.
- **Etiqueta de sección**: 13px, `font-weight:800`, `letter-spacing:1.5px`, color `brand/lavender-text`.
- **Título de pantalla**: Baloo 2, 800, 36px.
- **Título editorial**: Cormorant Garamond, 500, 34–42px, `line-height:1.05–1.1`.
- **Subtítulo editorial**: Cormorant Garamond, itálica 400, 17–18px, color `text/tertiary`.
- **Tagline del logo**: 9.5px, 700, `letter-spacing:2.4px`.

`text-wrap: pretty` es recomendable en párrafos.

### Espaciado

Escala usada (px): `3` `4` `5` `6` `7` `8` `9` `10` `11` `12` `13` `14` `16` `18` `20` `22` `24`
`26` `28` `30` `34` `36` `40` `46`

Padding de página: `30px 36px` (pantallas de contenido) · `28px 40px` a `34px 40px` (dashboard, tienda).
Gap de grilla: `14px` a `16px`. Gap de lista: `11px` a `14px`.

### Radios

| Valor | Uso |
|---|---|
| `7px` | Insignias pequeñas |
| `8px` | Chips, pestañas del toggle |
| `9px` | Botón primario estilo B |
| `10px` | Botones de la tienda |
| `11px` | Cápsulas de moneda, filtros, flechas cuadradas |
| `12px` | Íconos de nav, botones secundarios |
| `13px` | Inputs, ítems de nav |
| `14px` | Botón primario estilo A |
| `15px` | Tarjetas pequeñas, feedback |
| `16px` | Tarjetas de característica |
| `18px` | Tarjetas de contenido |
| `20px` | Tarjetas del mapa, pack de la tienda |
| `22px` | Paneles grandes |
| `24px` | Modal |
| `26px` a `30px` | Avatar del capibara |
| `50%` / `999px` | Flechas circulares, pastillas, avatares de profesor |

### Sombras

| Nombre | Valor |
|---|---|
| `shadow/primary` | `0 12px 26px rgba(124,58,237,.5), inset 0 1px 0 rgba(255,255,255,.3)` |
| `shadow/primary-b` | `0 4px 0 #5a23b3` (sólida, estilo B) |
| `shadow/card` | `0 8px 22px rgba(0,0,0,.45)` |
| `shadow/pin` | `0 8px 22px rgba(0,0,0,.5)` |
| `shadow/panel` | `0 16px 40px rgba(0,0,0,.5)` |
| `shadow/modal` | `0 30px 70px rgba(0,0,0,.6)` |
| `shadow/avatar` | `0 10px 28px rgba(124,58,237,.4)` |
| `shadow/character` | `drop-shadow(0 18px 30px rgba(0,0,0,.55))` |
| `shadow/success` | `0 16px 40px rgba(34,197,94,.45)` |
| `shadow/bubble` | `0 12px 30px rgba(0,0,0,.4)` |

### Otros

- `backdrop-filter: blur(6px)` en tarjetas flotantes sobre la escena; `blur(4px)` en el fondo del modal; `blur(8px)` en las tarjetas del mapa.
- Transiciones: `.12s ease` (botones), `.15s ease` (nav, flechas), `.18s ease` (tarjetas de tienda), `.2s ease` (puntos indicadores), `.25s ease` (toast).

---

## Layout general (shell)

Lienzo de diseño: **1440 × 900 px**, escalado con `transform: scale()` para caber en el viewport
(`Math.min(vw/1440, vh/900)`, `transform-origin: center`). En producción, hacerlo responsive real
en lugar de escalar.

Estructura:

```
┌──────────────────────────────────────────────────────────┐
│ TOP BAR  (74px)                                          │
├──────────┬───────────────────────────────────────────────┤
│ SIDEBAR  │  CONTENT                                      │
│ (212px)  │  (flex:1, position:relative, overflow:hidden) │
│          │                                               │
└──────────┴───────────────────────────────────────────────┘
```

Dos pantallas quedan **fuera** del shell (ocupan todo el lienzo): **Login** y **Sala en vivo**.

### Top bar (74px)

De izquierda a derecha:

1. **Logo** (ancho fijo 212px, alineado con la barra lateral): avatar del capibara 44×44 `border-radius:12px`
   + wordmark "CAPPILINGUA" (Baloo 2 800, 23px, degradado dorado con `background-clip:text`) +
   tagline "APRENDE · EXPLORA · CONECTA" (9.5px, 700, `letter-spacing:2.4px`, `#7a8298`).
2. **Cápsula de nivel** (`flex:1`, `max-width:560px`): ficha de estrella 44×44 con el número de nivel
   superpuesto, etiqueta "NIVEL 14", barra de progreso XP (11px de alto, `border-radius:7px`),
   y texto "2.780 / 4.200 XP".
3. **Espaciador** (`flex:1`).
4. **Saldo de wones**: ficha ₩ 20×20 + monto (Baloo 2 700, 16px).
5. **Saldo de gemas**: gema 20×20 + monto.
6. **Toggle de estilo A/B** (ver *Variantes de estilo*).
7. **Botón de ajustes** 44×44.

### Sidebar (212px)

`padding:18px 14px`, `gap:6px`. Ítems de nav: `padding:12px 14px`, `border-radius:13px`, ícono 22×22
+ etiqueta (Nunito 700, 15.5px).

- **Estado activo**: fondo `linear-gradient(100deg, rgba(124,58,237,.4), rgba(124,58,237,.12))`,
  borde `1px solid rgba(155,107,255,.45)`, texto `#ffffff`.
- **Inactivo**: fondo transparente, borde transparente, texto `#aeb6d0`. Hover: `filter:brightness(1.15)`.

Orden: Inicio · Clases en vivo · Misiones · Vocabulario · Avatar · Mapa Ciudad · Tienda —
espaciador (`flex:1`) — Ajustes — fila de iconos sociales (Discord, Instagram, Twitter, 19×19, `#5b647e`).

---

## Screens / Views

### 1. Login / Registro

**Propósito**: entrar a la app. Cualquier botón de acceso entra (prototipo sin autenticación real).

**Layout**: dos columnas, pantalla completa.

- **Izquierda (`flex:1`)**: hero. Imagen de la escena de Seúl a sangre (`object-fit:cover`, `object-position:center`)
  con overlay `linear-gradient(105deg, rgba(13,18,38,.92) 0%, rgba(13,18,38,.72) 38%, rgba(13,18,38,.25) 70%, rgba(13,18,38,.5) 100%)`.
  Contenido con `padding:48px 56px`, en columna: logo arriba, bloque de texto abajo (`margin-top:auto`).
  - Título: Baloo 2 800, 58px, `line-height:1.04`, `max-width:560px`. Texto: "Aprende idiomas explorando el mundo con tu **capibara**" (la palabra "capibara" en `accent/gold`).
  - Párrafo: 20px, `line-height:1.5`, `#c3c9de`, `max-width:480px`. "Explora ciudades increíbles, descubre palabras útiles y sumérgete en nuevas culturas con tu mejor compañero."
  - Tres tarjetas de característica (`max-width:420px`, `gap:13px`): `padding:15px 17px`, `border-radius:16px`,
    fondo `rgba(20,28,50,.66)`, borde `1px solid rgba(255,255,255,.09)`, `backdrop-filter:blur(6px)`.
    Cada una: ícono 42×42 `border-radius:12px` + título (800, 16px) + descripción (13.5px, `#aab2cc`).
    1. Libro / morado `rgba(124,58,237,.28)` — "Aprende vocabulario en contexto" / "Palabras útiles en situaciones reales de cada ciudad."
    2. Globo / azul `rgba(56,135,255,.26)` — "Explora ciudades únicas" / "Viaja por Seúl, Bogotá y muchas más por descubrir."
    3. Trofeo / dorado `rgba(245,196,81,.22)` — "Completa misiones y gana recompensas" / "Desafíos divertidos que te motivan a seguir aprendiendo."

- **Derecha (560px fijo)**: formulario. Fondo `#0e1426`, borde izquierdo hairline, `padding:46px 52px`,
  contenido centrado con `max-width:400px`.
  - Avatar del capibara 96×96, `border-radius:26px`, borde `3px solid rgba(155,107,255,.5)`, `shadow/avatar`.
  - Título "Bienvenido de nuevo" (Baloo 2 800, 32px). Subtítulo "Inicia sesión y continúa tu aventura" (15px, `#9aa3bf`).
  - Campo **Correo electrónico**: etiqueta (700, 14px, `#c3c9de`) + input 50px de alto, `border-radius:13px`, fondo `#161d33`, ícono de sobre 18×18. Placeholder `tu@email.com`.
  - Campo **Contraseña**: igual, con ícono de candado, `letter-spacing:2px`, placeholder `••••••••••`, y botón de ojo para alternar `type` entre `password` y `text`.
  - Enlace "¿Olvidaste tu contraseña?" alineado a la derecha (13.5px, 700, `brand/lavender-text`).
  - Botón primario ancho completo: "Iniciar sesión".
  - Divisor con texto "o continúa con" (13px, `#6f7896`, líneas hairline a los lados).
  - Tres botones sociales (50px, `border-radius:13px`, fondo `#1a2238`): Google (logo a color), Apple (blanco), Discord (`#5865F2`).
  - Pie: "¿No tienes cuenta? **Regístrate aquí**".

**Interacción**: cualquiera de los botones (Iniciar sesión, los tres sociales, Regístrate) navega al Dashboard.
El botón de ojo alterna la visibilidad de la contraseña.

---

### 2. Inicio / Dashboard

**Propósito**: punto de entrada. Resume el progreso y da acceso a profesores y clases.

**Layout**: columna con scroll vertical.

- **Hero** (`padding:34px 40px 30px`, borde inferior hairline): imagen de Seúl al `opacity:.22` con overlay
  `linear-gradient(120deg,#0b1120 18%, rgba(11,17,32,.6) 60%, rgba(124,58,237,.25))`.
  Fila: avatar 96×96 (`border-radius:26px`) + bloque de texto + botón "Ver clases de hoy".
  - Saludo "안녕하세요, viajero 👋" (14px, 700, `brand/lavender-text`).
  - Título "Sigue aprendiendo coreano con profes reales" (Baloo 2 800, 34px).
  - Tres métricas en fila (`gap:22px`, 14.5px, 700): 🔥 Racha de 12 días · 📚 532 palabras · 🎓 8 clases tomadas.

- **Cuerpo** (`padding:28px 40px`, `gap:28px` en columna):

  1. **Banner "Colabora con escuelas y profesores"**: `border-radius:22px`, `padding:26px 30px`,
     fondo `linear-gradient(110deg,#2a1a5e,#4322a3)`, borde `1px solid rgba(155,107,255,.4)`.
     Glifo 🤝 decorativo de 140px al `opacity:.14` arriba a la derecha. Contenido `max-width:760px`:
     micro-etiqueta en pastilla "COLABORA CON ESCUELAS Y PROFESORES", título (Baloo 2 800, 26px)
     "Aprende con profesores nativos y escuelas aliadas", párrafo (15px, `#d7d2f5`), y dos botones:
     "Explorar clases" (fondo `#fff`, texto `#3a1d8a`) y "Conocer profesores" (fantasma).

  2. **Profesores destacados**: encabezado con título (Baloo 2 800, 22px) y enlace "Ver todos →".
     Grilla de 3 columnas (`gap:16px`). Tarjeta: `padding:20px`, `border-radius:18px`, `surface/2`,
     borde `border/subtle`. Contiene avatar circular 52px con iniciales + nombre (Baloo 2 800, 17px)
     + "⭐ 4.9 · 312 reseñas" (12.5px) + especialidad (13.5px, `min-height:38px`) + dos botones:
     "Ver perfil" (tinte morado) y "Seguir"/"Siguiendo" (toggle).

  3. **Próximas clases en vivo**: encabezado con enlace "Ver agenda →". Grilla de 2 columnas.
     Tarjeta: ícono de cámara 60×60 en tinte morado + insignia EN VIVO (si aplica) + nivel +
     título (Baloo 2 800, 16px) + "profesor · horario" + botón de acción.

  4. **Fila inferior**: grilla `1.4fr 1fr`.
     - **Escuelas aliadas 🏫**: tres filas, cada una con ícono 44×44 en degradado, nombre (800, 15px),
       detalle (12.5px) y sello "Verificada ✓" (`status/success-light`).
       Seoul Language Institute (azul, TOPIK, 12 profes) · K-Culture Academy (rosa, cultura, 8 profes) ·
       Hangeul Online School (ámbar, gramática, 15 profes).
     - **Invitar y ganar 💎**: `linear-gradient(150deg,#7c3aed,#4322a3)`, glifo 🎁 de 110px al `opacity:.16`,
       título (Baloo 2 800, 19px), texto con "**200 gemas**" en negrita, botón blanco "Compartir invitación".

**Interacción**: "Ver clases de hoy" / "Explorar clases" / "Ver agenda" → Clases en vivo.
"Conocer profesores" / "Ver perfil" / nombre del profesor → Perfil de profesor. "Seguir" alterna el estado.
Los botones de clase se comportan como en Clases en vivo.

---

### 3. Clases en vivo

**Propósito**: ver la agenda de clases, unirse a una en vivo o reservar las próximas.

**Layout**: fondo de Seúl al `opacity:.1` con overlay `linear-gradient(180deg,rgba(11,17,32,.75),#0b1120)`.
Contenido con scroll, `padding:30px 36px`.

- Título "Clases en vivo 🎥" (Baloo 2 800, 36px) + subtítulo (15px, `#9aa3bf`)
  "Únete a clases con profesores nativos o reserva tu lugar en las próximas sesiones."
- **Pestañas de filtro** (`gap:10px`): Hoy · Esta semana · Todas · Mis clases.
  Activa: `linear-gradient(135deg,#9b6bff,#7c3aed)`, texto blanco, sin borde.
  Inactiva: `rgba(255,255,255,.05)`, texto `#aeb6d0`, borde `border/default`. `padding:10px 20px`, `border-radius:11px`.
- **Lista de clases** (`gap:14px`). Cada fila: `padding:18px`, `border-radius:18px`, `surface/2`, borde `border/subtle`.
  - Columna izquierda (72px, centrada): duración (Baloo 2 800, 13px, `brand/lavender-text`) + ícono de cámara 56×56.
  - Centro: insignia EN VIVO (si aplica) + chip de nivel + título (Baloo 2 800, 18px) +
    fila con avatar 34px del profesor, su nombre (13.5px, 700) y "· horario (GMT-5)".
  - Derecha: "👥 12/20 cupos" (12.5px) + botón de acción.

**Datos de las clases** (5):

| Título | Profesor | Cuándo | Nivel | Duración | Cupos | Estado |
|---|---|---|---|---|---|---|
| Cómo pedir comida en coreano | Minji | Hoy · 7:00 PM | Principiante | 45 min | 12/20 | EN VIVO |
| Conversación grupal para principiantes | David | Mañana · 6:00 PM | A1–A2 | 60 min | 8/15 | próxima |
| Partículas 은/는 vs 이/가 | Alex | Jue · 5:00 PM | Intermedio | 50 min | 5/12 | próxima |
| Pronunciación: sonidos difíciles | Jihoon | Vie · 8:00 PM | Todos | 40 min | 18/25 | próxima |
| K-Drama club: aprende con escenas | Minji | Sáb · 4:00 PM | Intermedio | 60 min | 9/20 | próxima |

**Botón de acción**, tres estados:
- En vivo → "Unirse ahora", `linear-gradient(135deg,#ef4444,#dc2626)` → abre la Sala en vivo.
- Disponible → "Reservar", degradado primario → añade a reservadas, toast "✅ ¡Clase reservada! La verás en «Mis clases»".
- Ya reservada → "Reservada ✓", fondo `rgba(255,255,255,.08)`.

**Filtros**: `hoy` y `semana` filtran por día; `todas` muestra las cinco; `mias` muestra solo las reservadas.

---

### 4. Perfil de profesor

**Propósito**: conocer al profesor, ver sus clases y reseñas, seguirlo o reservar una clase 1:1.

**Layout**: scroll vertical.

- **Encabezado** (`padding:30px 40px 26px`): fondo de Seúl al `opacity:.18` con overlay
  `linear-gradient(120deg,#0b1120 30%, rgba(11,17,32,.55))`.
  - Botón "← Volver" (fantasma, `padding:8px 14px`, `border-radius:10px`).
  - Fila: avatar circular 108px con iniciales + bloque de identidad + columna de acciones.
    - Nombre (Baloo 2 800, 30px) + chip de especialidad (fondo `rgba(245,196,81,.18)`, texto `accent/gold`).
    - Especialidad (15px, `#c3c9de`).
    - Cuatro métricas en fila (13.5px): ⭐ rating (reseñas) · 👥 estudiantes · 🎥 clases · 🗣 idiomas.
    - Acciones: botón primario "Reservar clase 1:1" (con ícono de calendario) + botón de seguir.

- **Cuerpo** (`padding:8px 40px 34px`, grilla `1.5fr 1fr`, `gap:24px`):
  - **Columna izquierda**: "Sobre mí" (título Baloo 2 800, 20px + párrafo 15px, `line-height:1.6`) y
    "Próximas clases" (lista de filas compactas: ícono 48×48, título 800/15px, "horario · nivel", botón de acción).
  - **Columna derecha**: "Reseñas". Tarjetas (`padding:16px`, `border-radius:15px`): nombre (800, 14px) +
    estrellas (`accent/gold`, 13px) + texto (13.5px, `line-height:1.5`).

**Datos de los profesores** (4):

| id | Nombre | Iniciales | Color | Chip | Especialidad | Rating | Reseñas | Estudiantes | Clases | Precio (gemas) | Idiomas |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `jihoon` | Profe Jihoon | JH | `#3b82f6` | Embajador | Conversación y cultura coreana | 4.9 | 312 | 1240 | 86 | 120 | 한국어 · Español |
| `minji` | Profe Minji | MJ | `#ec4899` | TOPIK | TOPIK I & II · Clases dinámicas | 4.8 | 248 | 980 | 120 | 100 | 한국어 · English |
| `alex` | Profe Alex | AX | `#22c55e` | Gramática | Gramática coreana con ejemplos prácticos | 4.7 | 189 | 760 | 64 | 90 | 한국어 · Español |
| `david` | Profe David | DV | `#f59e0b` | Pronunciación | Pronunciación y fluidez | 4.9 | 201 | 890 | 73 | 110 | 한국어 · Español |

Avatar del profesor: círculo con `linear-gradient(135deg, <color>, rgba(0,0,0,.25))`,
borde `2px solid rgba(255,255,255,.18)`, iniciales en Baloo 2 800 blanco.

Bios:
- Jihoon: "Profesor nativo de Seúl con 8 años de experiencia. Me especializo en conversación natural y en la cultura que hay detrás del idioma."
- Minji: "Preparo a mis estudiantes para el TOPIK con material exclusivo y muchísima práctica real."
- Alex: "Hago la gramática simple. Explicaciones claras paso a paso para que por fin entiendas las partículas."
- David: "Trabajamos tu acento y fluidez con técnicas de shadowing y feedback inmediato en cada sesión."

Reseñas (fijas, 3): Laura G. (5★) "Las clases son súper dinámicas, aprendí muchísimo de cultura coreana." ·
Carlos M. (5★) "Por fin entendí las partículas. Explica con mucha paciencia y ejemplos." ·
Sofía R. (4★) "Muy buen material y feedback constante. Recomendado para conversación."

---

### 5. Modal: Reservar clase 1:1

**Propósito**: elegir día y hora y confirmar la reserva pagando con gemas.

**Layout**: overlay `rgba(5,8,15,.72)` + `backdrop-filter:blur(4px)`, `z-index:90`, contenido centrado.
Tarjeta de 560px, `border-radius:24px`, fondo `#0e1426`, borde `1px solid rgba(155,107,255,.3)`,
`shadow/modal`, animación `popIn .3s ease`.

- **Encabezado** (`padding:24px 26px`, borde inferior hairline): botón de cerrar 36×36 arriba a la derecha,
  avatar 48px + micro-etiqueta "RESERVAR CLASE 1:1" + nombre (Baloo 2 800, 22px) + especialidad (13px).
- **Cuerpo** (`padding:24px 26px`, `gap:22px`):
  - "Elige el día": grilla de 5 columnas. Opciones: Lun 14 · Mar 15 · Mié 16 · Jue 17 · Vie 18.
    Seleccionado: fondo `#7c3aed`, texto blanco. Sin seleccionar: `rgba(255,255,255,.05)`, texto `#cfd5e8`.
  - "Elige el horario": grilla de 3 columnas. Opciones: 9:00 · 11:00 · 15:00 · 17:00 · 19:00 · 21:00.
    Seleccionado: degradado primario.
  - **Fila de precio**: `padding:16px 18px`, `border-radius:15px`, fondo `rgba(124,58,237,.12)`,
    borde `1px solid rgba(155,107,255,.3)`. "Precio de la clase (50 min)" + gema 22px + monto (Baloo 2 800, 24px)
    + "gemas", y a la derecha el botón primario "Confirmar reserva".

**Validación**:
- Sin horario elegido → toast "Elige un horario", no cierra.
- Gemas insuficientes → toast "Gemas insuficientes 💎", no cierra.
- Éxito → descuenta el precio, cierra el modal, toast "🎉 Clase 1:1 con {profesor} reservada".
- Clic en el fondo o en la X → cierra sin reservar. El clic dentro de la tarjeta no debe propagarse.

---

### 6. Sala en vivo (videollamada)

**Propósito**: simular la clase en vivo. **Pantalla completa, sin barra superior ni lateral.**

**Layout**: columna sobre fondo `#070b15`.

- **Barra superior** (`padding:14px 22px`, fondo `bg/chrome`, borde inferior hairline):
  insignia "● EN VIVO" (fondo `status/live`) + título de la clase (Baloo 2 800, 17px) +
  "· nombre del profesor" (13px) + espaciador + cronómetro "🕐 24:18".

- **Cuerpo** (`flex:1`, dos columnas):
  - **Escenario** (`flex:1`, `padding:18px`, `gap:14px`):
    1. **Video principal** (`flex:1`, `border-radius:20px`): fondo
       `radial-gradient(120% 100% at 50% 0%, #1c2748, #0b1120)` + imagen de Seúl al `opacity:.14`.
       Centrado: avatar del profesor 120px con animación `capFloat`, su nombre (Baloo 2 800, 22px),
       y una burbuja blanca con la frase coreana "커피 주세요 ☕" (fondo `rgba(255,255,255,.95)`,
       texto `#1a2238`, Baloo 2 700, 24px, `border-radius:12px`, `shadow/bubble`).
       Etiqueta "🎤 {profesor}" arriba a la izquierda (fondo `rgba(0,0,0,.55)`).
       **PIP propio** abajo a la derecha: 170×108, `border-radius:14px`, borde `2px solid #9b6bff`,
       imagen del capibara, etiqueta "Tú".
    2. **Tira de participantes** (centrada, `gap:10px`): pastillas con avatar cuadrado 44×44 y nombre (13px).
       Tú (`#7c3aed`) · Ana (`#ec4899`) · Luis (`#22c55e`) · Yuna (`#f59e0b`) · Min (`#3b82f6`).
    3. **Controles** (centrados, `gap:14px`): tres botones cuadrados 54×54 (`border-radius:16px`,
       fondo `surface/3`): micrófono, cámara, compartir pantalla. Luego el botón "Salir"
       (54px de alto, `padding:0 26px`, `linear-gradient(135deg,#ef4444,#dc2626)`, ícono de teléfono rotado 135°).

  - **Chat** (330px, fondo `bg/chrome`, borde izquierdo hairline):
    - Encabezado "Chat de la clase" (`padding:16px 18px`, Baloo 2 800, 16px, borde inferior hairline).
    - Lista con scroll (`padding:16px 18px`, `gap:12px`). Dos tipos de mensaje:
      - **Sistema**: centrado, 12px, `#7a8298`, itálica.
      - **Normal**: autor (11.5px, 800, `brand/lavender-text`) sobre el texto (13.5px, `#dfe3f1`).
    - Composer (`padding:14px`, borde superior hairline): input (44px, `border-radius:12px`, fondo `#161d33`,
      placeholder "Escribe un mensaje…") + botón cuadrado 44×44 `#7c3aed` con ícono de avión.

**Mensajes iniciales** al entrar:
1. sistema — "Te uniste a la clase. ¡Saluda! 👋"
2. Profe — "안녕하세요! Bienvenidos, vamos a empezar."
3. Ana — "Hola a todos 🙌"

**Interacción**: enviar añade el mensaje como autor "Tú" y limpia el input (ignora texto vacío).
"Salir" vuelve a Clases en vivo. Los controles de micro/cámara/pantalla son decorativos (toast de demo).

---

### 7. Misiones

**Propósito**: ver retos, seguir el progreso y reclamar recompensas.

**Layout**: fondo de Seúl al `opacity:.12` con overlay `linear-gradient(180deg,rgba(11,17,32,.7),#0b1120)`.
`padding:30px 36px`.

- Título "Misiones" (Baloo 2 800, 36px) + subtítulo "Completa retos, gana XP y desbloquea nuevos lugares de Seúl."
- **Pestañas** en contenedor segmentado (`max-width:460px`, `padding:6px`, `border-radius:15px`,
  fondo `surface/1`, borde `border/subtle`): Diarias · Historia · Desafíos.
  Activa: degradado primario, texto blanco. Inactiva: transparente, texto `#aeb6d0`.
- **Lista** (`max-width:920px`, `gap:14px`). Tarjeta: `display:flex`, `gap:16px`, `padding:18px`, `border-radius:18px`,
  `surface/1`, borde `border/subtle`. Si está bloqueada: `opacity:.62`.
  - Ícono emoji 64×64 en tinte morado `border-radius:16px`.
  - Centro: título (Baloo 2 800, 18px) + descripción (13.5px, `#9aa3bf`) + barra de progreso
    (`max-width:300px`, 10px de alto, `border-radius:6px`, fondo `rgba(0,0,0,.4)`) + "2/3" (12.5px, 700).
    Relleno de la barra: degradado primario normalmente; degradado dorado si está lista para reclamar o ya reclamada.
  - Derecha: recompensas (gema + XP, ficha ₩ + wones) y el botón de acción.

**Datos de las misiones**:

| Pestaña | Emoji | Título | XP | Wones | Progreso | Estado |
|---|---|---|---|---|---|---|
| Diarias | ☕ | Pide un café en coreano | 150 | 2.500 | 2/3 | activa |
| Diarias | 💬 | Saluda a 5 personas | 80 | 1.200 | 5/5 | reclamable |
| Diarias | 📚 | Aprende 10 palabras nuevas | 100 | 1.500 | 7/10 | activa |
| Historia | 🚇 | Encuentra la estación de metro | 120 | 2.000 | 0/1 | activa |
| Historia | 🗼 | Llega a la Torre de Seúl | 200 | 3.000 | 1/1 | reclamable |
| Desafíos | 🔥 | Mantén una racha de 14 días | 250 | 4.000 | 12/14 | activa |
| Desafíos | 🌃 | Visita Myeongdong de noche | 300 | 5.000 | 0/1 | bloqueada (nivel 16) |

Descripciones: "Aprende a ordenar en una cafetería de Myeongdong." · "Practica saludos formales e
informales por la ciudad." · "Amplía tu vocabulario de comida coreana." · "Usa el coreano para navegar
el subte de Seúl." · "Sube por la colina de Namsan hablando coreano." · "Practica todos los días sin
fallar." · "Se desbloquea al alcanzar el nivel 16."

**Botón por estado**:
- `activa` → "Continuar" (degradado primario) → abre la Lección.
- `reclamable` → "Reclamar" (`linear-gradient(135deg,#ffd980,#f2a93a)`, texto `#0b1120`) → suma wones,
  toast "¡Recompensa reclamada! +{xp} XP · +₩{wones}".
- `reclamada` → "Reclamado ✓" (deshabilitado, `surface/3`).
- `bloqueada` → "Nivel 16" (deshabilitado, `cursor:not-allowed`) → toast "🔒 Alcanza el nivel 16 para desbloquear".

---

### 8. Lección (pregunta / respuesta)

**Propósito**: responder una tanda de 3 preguntas y recibir la recompensa.

**Layout**: `radial-gradient(120% 80% at 50% 0%, #182241, #0b1120 70%)`, columna, sin barra lateral visible
(usa el shell pero ocupa todo el área de contenido).

- **Encabezado** (`padding:22px 40px`): botón de cerrar 42×42 (X) + barra de segmentos + contador de aciertos.
  - Segmentos: uno por pregunta, `flex:1`, 12px de alto, `border-radius:7px`, fondo `rgba(255,255,255,.08)`.
    Completado: `linear-gradient(90deg,#22c55e,#5ee08a)`.
  - Contador: estrella dorada + número (Baloo 2, 15px, `accent/gold`).

- **Cuerpo** (`flex:1`, centrado, `gap:40px`, `padding:10px 40px 30px`):
  - **Izquierda (280px)**: burbuja blanca con la frase coreana (Baloo 2 700, 24px, `border-radius:18px`,
    `shadow/bubble`, con triangulito inferior de 11px) sobre el capibara de 200px (`border-radius:28px`,
    `drop-shadow(0 16px 26px rgba(0,0,0,.5))`, animación `capFloat`).
  - **Derecha (`max-width:620px`)**: micro-etiqueta "PREGUNTA 1 DE 3" (14px, 800, `letter-spacing:1.5px`,
    `brand/lavender-text`), enunciado (Baloo 2 800, 30px, `line-height:1.2`), y grilla de 2×2 con las opciones.
    - Opción: `padding:18px 20px`, `border-radius:15px`, fondo `surface/1`, borde `2px solid rgba(255,255,255,.1)`.
      Texto principal Baloo 2 700, 22px; subtexto 13.5px al `opacity:.8`.
    - Seleccionada (sin comprobar): fondo `rgba(124,58,237,.2)`, borde `2px solid #9b6bff`.
    - Tras comprobar — correcta: fondo `rgba(34,197,94,.16)`, borde `2px solid #22c55e`, texto `#d6ffe2`, marca "✓".
    - Tras comprobar — elegida e incorrecta: fondo `rgba(239,68,68,.14)`, borde `2px solid #ef4444`, texto `#ffd9d9`, marca "✕".

- **Pie** (`padding:18px 40px 30px`, borde superior hairline, contenido `max-width:920px` centrado):
  - Antes de comprobar: texto "Selecciona una respuesta y comprueba." + botón "COMPROBAR"
    (`min-width:200px`). Deshabilitado (fondo `rgba(255,255,255,.08)`, texto `#6f7896`) hasta elegir opción.
  - Después: panel de feedback (`flex:1`, `padding:16px 20px`, `border-radius:15px`;
    correcto → fondo `rgba(34,197,94,.14)`, borde `rgba(34,197,94,.5)`, texto `#5ee08a`, emoji 🎉;
    incorrecto → fondo `rgba(239,68,68,.12)`, borde `rgba(239,68,68,.5)`, texto `#ff8585`, emoji 💪)
    + botón "CONTINUAR" (o "FINALIZAR" en la última).
    Textos: "¡Correcto! 잘했어요!" / "Casi... la respuesta correcta está marcada."

**Preguntas**:

1. "¿Cómo se dice «Hola» de forma formal?" — burbuja `안녕하세요?` — opciones: **안녕하세요** (Hola (formal)) ✓ · 감사합니다 (Gracias) · 사랑해요 (Te quiero) · 잘 가요 (Adiós).
2. "Estás en una cafetería. ¿Cómo pides un café?" — burbuja `커피 한 잔이요!` — opciones: **커피 주세요** (Un café, por favor) ✓ · 물 주세요 (Agua, por favor) · 얼마예요? (¿Cuánto cuesta?) · 화장실 어디예요? (¿Dónde está el baño?).
3. "¿Qué significa «맛있어요»?" — burbuja `맛있어요!` — opciones: **Está delicioso** ✓ · Estoy lleno · Qué caro · Buenos días.

**Pantalla de finalización** (al terminar las 3): ícono de check 120px en círculo
`linear-gradient(135deg,#22c55e,#16a34a)` con `shadow/success` y animación `pulseRing 1.6s ease-out infinite`;
título "¡Misión completada!" (Baloo 2 800, 40px); subtítulo "Pediste tu café en coreano · {aciertos}/3 aciertos";
dos tarjetas de recompensa (+150 XP en tinte morado, +2.500 Wones en tinte celadón); botón "VOLVER AL MAPA"
(`min-width:280px`) que suma la recompensa **una sola vez**, vuelve al mapa y lanza el toast "🎉 +150 XP · +₩2.500".

---

### 9. Avatar / Personalización

**Propósito**: vestir al personaje recorriendo opciones por parte del cuerpo.

Esta pantalla toma su registro visual del sitio de referencia
[Anatomy Atelier](https://anatomyatelier.vercel.app/en): tipografía serif, micro-etiquetas en
versalitas, glifos finos en vez de emoji, separadores hairline y mucho aire.

**Layout**: dos columnas, `gap:18px`, `padding:18px`.

- **Izquierda (`flex:1`) — vista previa**: `border-radius:22px`, imagen de Seúl (`object-position:center 36%`)
  con overlay `linear-gradient(180deg, rgba(11,17,32,.4), rgba(11,17,32,.15) 35%, rgba(11,17,32,.85))`.
  **Aquí va el canvas de three.js con el personaje.**
  - Arriba a la izquierda: pin + "SEÚL" (Baloo 2 800, 30px) + "COREA DEL SUR 🇰🇷" (Baloo 2 700, 14px).
  - Centrado (`bottom:118px`): personaje 230×230 (`border-radius:30px`, `shadow/character`, animación `capFloat`)
    y debajo una pastilla "EXPLORADOR NOVATO" (Baloo 2 800, 15px, fondo `rgba(12,18,34,.85)`,
    borde `1px solid rgba(155,107,255,.4)`, con ícono de lápiz).
  - **Barra de estadísticas** abajo (`left/right:18px`, `bottom:18px`): `padding:14px`, `border-radius:18px`,
    fondo `rgba(12,18,34,.82)`, `backdrop-filter:blur(6px)`. Cuatro columnas separadas por líneas de 1px:
    RACHA 🔥 12 días · VOCABULARIO 532 palabras · MISIONES 45 completadas · CIUDADES 2/10 visitadas.
    (Etiqueta 11px `letter-spacing:1px`; número Baloo 2 800, 26px; unidad 11px `#7a8298`.)

- **Derecha (420px fijo) — panel editorial**: `border-radius:22px`, fondo `bg/panel-alt`, borde `border/subtle`.
  - **Encabezado** (`padding:28px 28px 20px`, borde inferior hairline):
    micro-etiqueta "ATELIER · SEÚL" (10.5px, `letter-spacing:3.2px`),
    título "Personalizá tu personaje" (Cormorant Garamond 500, 34px, `line-height:1.1`),
    subtítulo "Ajustá cada detalle de tu viajero." (Cormorant itálica, 17px, `#9aa3bf`),
    y dos botones pastilla de contorno (`border-radius:999px`, `padding:11px`, borde `border/strong`):
    "✦ Aleatorio" (glifo en `brand/lavender`) y "↺ Restablecer".
  - **Filas de partes** (`padding:6px 28px`, con scroll). Cada fila: `padding:17px 0`,
    borde inferior hairline.
    - Cabecera de fila: número de dos dígitos (Cormorant, 13px, `#6f7896`) + etiqueta en versalitas
      (10.5px, 700, `letter-spacing:2.2px`, `#9aa3bf`) a la izquierda; glifo (13px, `#7c6bb0`) a la derecha.
    - Control: flecha circular 34px a cada lado (borde `1px solid rgba(255,255,255,.16)`, fondo transparente;
      hover → fondo `rgba(255,255,255,.1)`, borde `rgba(255,255,255,.4)`), y en el centro
      la miniatura del ítem (30×30, si existe) + el valor (Cormorant Garamond 500, 22px) y debajo
      el **indicador de puntos**: un punto de 5px por opción; el activo mide 16×5 y es `brand/lavender`
      (`transition:all .2s ease`).
  - **Pie** (`padding:20px 28px 24px`, borde superior hairline): botón "Tienda" (contorno) +
    botón primario "GUARDAR CAMBIOS" (`flex:1`).

**Partes y opciones** (9 filas, con su glifo):

| # | Parte | Glifo | Opciones |
|---|---|---|---|
| 01 | Pelo | ❋ | Corto · Largo · Rizado · Recogido · Trenzas |
| 02 | Expresión | ◈ | Feliz · Serio · Sorprendido · Guiño · Dormido |
| 03 | Torso | ◇ | Remera · Hoodie Morado · Camiseta 서울 · Hanbok · Chaqueta |
| 04 | Piernas | ⌁ | Jeans · Cargo · Short · Falda |
| 05 | Calzado | ⌖ | Zapatillas · Ojotas A · Botas · Sandalias |
| 06 | Sombrero | ✦ | Ninguno · Gorro SEÚL · Bucket 서울 · Gorro Rana · Sombrero Negro |
| 07 | Accesorios | ✧ | Ninguno · Gafas Redondas · Audífonos · Mascarilla 안녕 · Cámara |
| 08 | Mochila | ✿ | Ninguna · I♥KOREA · Mochila Army · Mochila Escolar · Mochila Oso |
| 09 | Compañero | ♙ | Ninguno · Gato · Pájaro · Perro · Zorro |

Selección inicial (índices): pelo 1, expresión 0, torso 0, piernas 1, calzado 1, sombrero 1,
accesorios 1, mochila 1, compañero 1.

Las opciones de Sombrero, Accesorios y Mochila tienen miniatura asociada (ver **Assets**).

**Interacción**: las flechas **ciclan** las opciones (`(i ± 1 + n) % n`, sin topes).
"Aleatorio" asigna un índice al azar a cada parte y lanza el toast "🎲 ¡Look aleatorio generado!".
"Restablecer" vuelve a la selección inicial, toast "↺ Look restablecido".
"Guardar cambios" → toast "✅ ¡Cambios guardados!". "Tienda" → pantalla de Tienda.

---

### 10. Tienda

**Propósito**: comprar artículos con wones (₩) y gemas.

**Layout**: scroll vertical, mismo registro editorial que el panel de personalización.

- **Encabezado** (`padding:34px 40px 28px`, borde inferior hairline): imagen de Seúl al `opacity:.14`
  con overlay `linear-gradient(115deg,#0b1120 25%, rgba(11,17,32,.6))`.
  - Izquierda: micro-etiqueta "MERCADO · 시장", título "Tienda" (Cormorant Garamond 500, 42px),
    subtítulo "Gastá tus wones en piezas para tu personaje." (Cormorant itálica, 18px).
  - Derecha: dos tarjetas de saldo (`padding:14px 20px`, `border-radius:15px`):
    **TUS WONES** (fondo `rgba(79,179,168,.12)`, borde `rgba(79,179,168,.32)`, etiqueta `#8fd8cf`) y
    **GEMAS** (fondo `rgba(124,58,237,.14)`, borde `rgba(155,107,255,.32)`, etiqueta `brand/lavender`).
    Monto en Baloo 2 800, 22px, con su ficha de 20px.

- **Cuerpo** (`padding:24px 40px 34px`):
  1. **Pack destacado**: `border-radius:20px`, `padding:24px 28px`, `margin-bottom:26px`,
     fondo `linear-gradient(110deg,#20183f,#3d2585)`, borde `1px solid rgba(155,107,255,.35)`,
     glifo ✦ de 150px al `opacity:.1`. Micro-etiqueta "PACK DESTACADO",
     título "Colección Seúl completa" (Cormorant 500, 28px), descripción
     "Cinco piezas exclusivas de la ciudad: bucket, gorro rana, sombrero negro, cámara y mochila army.",
     precio tachado ₩30.000 sobre ₩24.000 (Baloo 2 800, 26px) y botón blanco "Comprar pack".
  2. **Pestañas de categoría** (pastillas, `border-radius:999px`, `padding:9px 18px`):
     Destacados · Ropa · Accesorios · Compañeros · Potenciadores.
     Activa: fondo `#eef1fb`, texto `#0b1120`. Inactiva: transparente, texto `#9aa3bf`, borde `rgba(255,255,255,.14)`.
  3. **Grilla de 4 columnas** (`gap:16px`). Tarjeta (`padding:18px`, `border-radius:18px`, `surface/1`,
     borde `border/subtle`; hover → borde `rgba(155,107,255,.4)` y `translateY(-2px)`):
     chip de etiqueta arriba a la derecha (si tiene), zona de imagen de 96px de alto (miniatura
     `max-height:92px` o emoji de 54px), nombre (Cormorant Garamond 500, 20px),
     descripción opcional (12px, `#8a93ad`), precio (ficha + Baloo 2 800, 18px) y botón ancho completo.
     Botón: "Comprar" (fondo `#eef1fb`, texto `#0b1120`) o "Adquirido" (transparente, borde hairline,
     texto `#6f7896`, `cursor:default`).

**Catálogo** (17 artículos):

| id | Categoría | Nombre | Arte | Precio | Moneda | Etiqueta |
|---|---|---|---|---|---|---|
| `bucket` | Ropa | Bucket 서울 | imagen | 4.500 | won | Nuevo |
| `frog` | Ropa | Gorro Rana | imagen | 5.200 | won | — |
| `hat` | Ropa | Sombrero Negro | imagen | 6.000 | won | — |
| `hanbok` | Ropa | Hanbok | 👘 | 12.000 | won | Edición |
| `headphones` | Accesorios | Audífonos | imagen | 5.500 | won | — |
| `mask` | Accesorios | Mascarilla 안녕 | imagen | 3.800 | won | — |
| `camera` | Accesorios | Cámara | imagen | 7.200 | won | Nuevo |
| `army` | Accesorios | Mochila Army | imagen | 6.500 | won | — |
| `school` | Accesorios | Mochila Escolar | imagen | 5.800 | won | — |
| `bear` | Accesorios | Mochila Oso | imagen | 7.000 | won | — |
| `bird` | Compañeros | Pájaro | 🐦 | 120 | gema | — |
| `dog` | Compañeros | Perro | 🐶 | 140 | gema | — |
| `fox` | Compañeros | Zorro | 🦊 | 160 | gema | Raro |
| `boost_streak` | Potenciadores | Escudo de racha | 🔥 | 3.000 | won | — |
| `boost_xp` | Potenciadores | Doble XP · 1h | ⚡ | 4.500 | won | — |
| `boost_life` | Potenciadores | Vidas extra | ❤️ | 2.000 | won | — |
| `pass` | Potenciadores | Pase mensual | 🎫 | 250 | gema | Popular |

Descripciones de los potenciadores: "Protege tu racha un día" · "Duplica la XP que ganes" ·
"Cinco intentos más" · "Clases ilimitadas".

La pestaña **Destacados** muestra únicamente los artículos que tienen etiqueta (Nuevo, Edición, Raro, Popular).

**Reglas de compra**:
- Ya comprado → toast "Ya tienes este artículo".
- Saldo insuficiente → toast "Wones insuficientes ₩" o "Gemas insuficientes 💎".
- Éxito → descuenta del saldo correspondiente, añade el id a `owned`, toast "✓ {nombre} adquirido".
- **Pack**: cuesta ₩24.000 y otorga `bucket`, `frog`, `hat`, `camera`, `army` de una vez
  (usar conjunto para no duplicar). Toast "✓ Pack Seúl adquirido".

---

### 11. Mapa de la ciudad (Seúl) — estilo Kakao Maps

**Propósito**: navegar la ciudad y entrar a los lugares de práctica. **Aquí va la escena de three.js.**

El chrome de esta pantalla sigue el patrón de **Kakao Maps** (buscador flotante, chips de categoría,
pines teardrop, controles agrupados, bottom sheet del lugar), pero con la paleta oscura de la app en
lugar del blanco y amarillo de Kakao.

**Layout**: el mapa ocupa todo el área de contenido; la UI flota encima con `z-index`.

#### Contenedor del mapa y zoom

```
<div style="position:absolute; inset:0; transform:scale(z); transform-origin:center; transition:transform .3s ease">
  <img src="…" style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover">
  …pines…
</div>
```

**Crítico**: el mapa y los pines deben vivir en el **mismo contenedor escalado**. Escalar solo la
imagen desincroniza los pines. Cada pin se **contra-escala** con `scale(1/z)` y
`transform-origin:bottom center` para conservar su tamaño en pantalla mientras su punta sigue
anclada al mismo punto del mapa.

`z` va de **1 a 1.6** en pasos de **0.15**. El indicador muestra `Math.round(z*100)+'%'`.

**Aspecto de la imagen**: el área de contenido es ~1228×827 (≈1.49:1). Si la imagen es mucho más
apaisada, `object-fit:cover` recorta a los lados y parte los rótulos pintados en el mapa. El asset
entregado (1100×667, ≈1.65:1) está recortado en vertical para que la pérdida lateral sea mínima.
Al cambiar el mapa, **recortar en vertical, no dejar que CSS recorte en horizontal**, y volver a
ajustar los porcentajes de los pines.

**Velos**: dos degradados a `#080c18` (arriba 140px, abajo 95px, `pointer-events:none`, `z-index:5`)
funden el mapa con el chrome de la app y ocultan los restos de UI incrustada en el asset de referencia.

#### Buscador y chips (arriba a la izquierda, `top:18px; left:20px`)

- **Buscador**: 360×48, `border-radius:13px`, fondo `rgba(12,18,34,.92)`, borde `rgba(255,255,255,.12)`,
  `backdrop-filter:blur(8px)`, sombra `0 6px 22px rgba(0,0,0,.45)`. Lupa 19×19 (`#7e88a6`),
  placeholder "Buscar lugar en Seúl", divisor vertical y botón 34×34 con degradado primario que va a Vocabulario.
- **Chips de categoría** (`gap:8px`, `max-width:520px`): pastillas de 34px de alto, `border-radius:999px`,
  con un punto de 8px del color de la categoría + su nombre.
  - Activo: `linear-gradient(135deg,#9b6bff,#7c3aed)`, texto `#fff`, borde `rgba(155,107,255,.55)`.
  - Inactivo: `rgba(12,18,34,.86)`, texto `#cfd5e8`, borde `rgba(255,255,255,.12)`.

| Categoría | Color |
|---|---|
| Todos | `#c4a6ff` |
| Cultura | `#ef4d6d` |
| Compras | `#f5c451` |
| Ocio | `#9b6bff` |
| Naturaleza | `#4fb3a8` |

#### Pines

Forma **teardrop** de Kakao: 32×32, `border-radius:50% 50% 50% 0`, `transform:rotate(-45deg)`,
relleno del color de su categoría (gris `#8b95a1` si está bloqueado), borde `2.5px` claro.
El glifo interior se contra-rota con `rotate(45deg)`.

- Normal: borde `rgba(238,241,251,.85)`, sombra `0 4px 12px rgba(0,0,0,.5)`.
- Seleccionado: `scale(1.18)`, borde `#eef1fb`, halo `0 0 0 5px <color>44`, `z-index:12`.

Glifos por categoría: Cultura ⛩ · Compras 🛍 · Ocio 🎤 · Naturaleza 🌿 · bloqueado 🔒.

**Los pines no llevan etiqueta de texto**: el mapa ya trae los nombres pintados. Si se reemplaza por
un mapa sin rótulos, activar etiquetas DOM usando `name` de cada lugar.

**Lugares** (posición en % del contenedor):

| id | Nombre | Coreano | Categoría | top | left | Progreso | Estado |
|---|---|---|---|---|---|---|---|
| `tower` | N Seoul Tower | 남산서울타워 | Cultura | 21% | 23.5% | 6/12 | abierto |
| `gangnam` | Gangnam | 강남 | Compras | 28% | 60% | 5/12 | abierto |
| `lotte` | Lotte World Tower | 롯데월드타워 | Compras | 45% | 83% | 3/12 | abierto |
| `palace` | Gyeongbokgung | 경복궁 | Cultura | 56% | 31.5% | 0/12 | **bloqueado** |
| `han` | Río Han | 한강 | Naturaleza | 60% | 86.5% | 8/12 | abierto |
| `hongdae` | Hongdae | 홍대 | Ocio | 79.5% | 86% | 9/12 | abierto |

Descripciones: "Mirador sobre la ciudad y los candados del amor en Namsan." · "Distrito moderno de
tiendas, cafés y karaokes." · "La torre más alta de Corea, con centro comercial y acuario." ·
"Palacio real de la dinastía Joseon. Cambio de guardia cada hora." · "Paseos en bici, picnic y barcos
al atardecer." · "Vida nocturna, música en vivo y arte callejero."

#### Insignia de ciudad (arriba a la derecha)

Panel oscuro con 🇰🇷 + "SEÚL" (Baloo 2 800, 15px) + "Nivel 14 · 2.780 XP" (10.5px, `#9aa3bf`) + chevron.

#### Tarjeta de misión (`top:80px; right:20px`, 318px)

Fila clicable: ícono ☕ 44×44 en `rgba(245,196,81,.16)`, micro-etiqueta "MISIÓN ACTUAL"
(9.5px, `letter-spacing:1.8px`, `#a78bff`), título, y recompensas (gema 150 · ₩2.500). Abre la Lección.
Borde `rgba(155,107,255,.28)`.

#### Barra de controles (abajo al centro)

Una sola barra horizontal (`border-radius:14px`, panel oscuro, `backdrop-filter:blur(8px)`):
compás N con aguja `#ef4d6d` · divisor · **−** · porcentaje de zoom · **+** · divisor · recentrar.
Botones de 40×40, color `#cfd5e8`.

Recentrar devuelve `z` a 1 y lanza el toast "📍 Vista centrada en Seúl".

#### Ficha del lugar (bottom sheet, abajo a la izquierda, 390px)

`border-radius:18px`, fondo `rgba(12,18,34,.94)`, borde `rgba(155,107,255,.28)`,
`backdrop-filter:blur(10px)`, sombra `0 14px 38px rgba(0,0,0,.55)`.

- Nombre (Baloo 2 800, 21px) + nombre coreano (12.5px, `#7a8298`).
- Chip de categoría con el color de su categoría al 15% de fondo.
- Contador de estrellas "9/12" en cápsula `rgba(255,255,255,.06)`.
- Descripción (13.5px, `#9aa3bf`).
- Barra de progreso de 8px con `linear-gradient(90deg,<color>aa,<color>)` + porcentaje.
- Acciones: **"Practicar aquí"** (degradado primario, abre la Lección) y **"Vocabulario"** (fantasma).
  Si el lugar está bloqueado: el botón dice "Bloqueado", va en `rgba(255,255,255,.07)` con
  `cursor:not-allowed` y lanza el toast "🔒 Sigue jugando para desbloquear este lugar".

#### Estado

`place` (id seleccionado, inicial `'hongdae'`) · `pcat` (filtro, inicial `'todos'`) ·
`mapZoom` (inicial `1`).

---

### 12. Vocabulario

**Propósito**: consultar las palabras aprendidas.

**Layout**: fondo de Seúl al `opacity:.16` con overlay `linear-gradient(180deg,#0b1120,rgba(11,17,32,.85))`.
`padding:30px 36px`.

- Encabezado: título "Vocabulario · Seúl 🇰🇷" (Baloo 2 800, 36px) + subtítulo
  "{n} palabras descubiertas · toca 🔊 para escuchar la pronunciación", y a la derecha un buscador
  (48px de alto, `min-width:240px`, `border-radius:13px`, ícono de lupa, placeholder "Buscar palabra…").
- **Filtros** (pastillas, `padding:9px 18px`, `border-radius:11px`): Todas · Saludos · Comida · Transporte · Compras.
  Activo: degradado primario.
- **Grilla de 3 columnas** (`gap:16px`). Tarjeta (`padding:22px`, `border-radius:18px`, `surface/2`):
  chip de categoría (fondo `rgba(124,58,237,.22)`, texto `brand/lavender`) y estrella de "aprendida"
  arriba; palabra coreana (Baloo 2 700, 34px); romanización (14px, itálica, `#9aa3bf`);
  separador hairline; traducción (16px, 700) y botón de audio 40×40 (tinte morado).
  La estrella está rellena en `accent/gold` si la palabra está aprendida, y solo contorneada (`#5b647e`) si no.

**Palabras** (9):

| Coreano | Romanización | Español | Categoría | Aprendida |
|---|---|---|---|---|
| 안녕하세요 | annyeonghaseyo | Hola (formal) | Saludos | sí |
| 감사합니다 | gamsahamnida | Gracias | Saludos | sí |
| 사랑해요 | saranghaeyo | Te quiero | Saludos | no |
| 커피 | keopi | Café | Comida | sí |
| 물 | mul | Agua | Comida | sí |
| 맛있어요 | masisseoyo | Está delicioso | Comida | no |
| 지하철 | jihacheol | Metro | Transporte | sí |
| 얼마예요? | eolmayeyo | ¿Cuánto cuesta? | Compras | no |
| 화장실 | hwajangsil | Baño | Lugares | sí |

El botón de audio lanza el toast "🔊 {romanización}" (en producción: TTS o audio real).
La estrella lanza "⭐ ¡Palabra aprendida!" / "Marcada como pendiente" (en el prototipo no persiste;
en producción debe alternar el estado real).

---

## Interactions & Behavior

### Navegación

| Desde | Acción | Destino |
|---|---|---|
| Login | cualquier botón de acceso | Dashboard |
| Sidebar | Inicio / Clases en vivo / Misiones / Vocabulario / Avatar / Mapa Ciudad / Tienda | pantalla correspondiente |
| Dashboard | "Ver clases de hoy", "Explorar clases", "Ver agenda →", "Ver todos →" | Clases en vivo |
| Dashboard | "Conocer profesores", "Ver perfil", nombre del profesor | Perfil de profesor |
| Clases en vivo | avatar o nombre del profesor | Perfil de profesor |
| Clases en vivo / Dashboard | "Unirse ahora" | Sala en vivo |
| Perfil | "Reservar clase 1:1" | abre el modal de reserva |
| Perfil | "← Volver" | Clases en vivo |
| Sala en vivo | "Salir" | Clases en vivo |
| Misiones / Mapa | "Continuar" / "CONTINUAR MISIÓN" | Lección |
| Lección | X (cerrar) | Mapa de la ciudad |
| Lección (fin) | "VOLVER AL MAPA" | Mapa de la ciudad + recompensa |
| Avatar | "Tienda" | Tienda |

Las pantallas **Login** y **Sala en vivo** ocultan el shell (barra superior y lateral).

### Toasts

Notificación efímera: `position:absolute`, `bottom:34px`, centrada con `translateX(-50%)`, `z-index:80`,
`padding:14px 24px`, `border-radius:14px`, fondo `#1a2238`, borde `1px solid rgba(155,107,255,.4)`,
`shadow/panel`, 15px/700, animación `toastIn .25s ease`. **Se cierra solo a los 2.200 ms**
(cancelar el temporizador anterior en cada nuevo toast, y limpiarlo al desmontar).

### Animaciones (`@keyframes`)

| Nombre | Definición | Uso |
|---|---|---|
| `capFloat` | `0%,100% { translateY(0) }` · `50% { translateY(-9px) }`, `4s ease-in-out infinite` | Personaje flotando |
| `popIn` | `0% { scale(.92) }` → `100% { scale(1) }`, `.3s–.4s ease` | Modal y pantalla de fin de lección |
| `toastIn` | `0% { translate(-50%,16px); opacity:0 }` → `100% { translate(-50%,0); opacity:1 }`, `.25s ease` | Toast |
| `pulseRing` | halo `box-shadow` de 0 → 12px que se desvanece, `1.6s ease-out infinite` | Check de misión completada |

**Cuidado**: `popIn` **no debe animar `opacity`**. Animarla provocó un bug real (la tarjeta quedaba
invisible al reiniciarse la animación en un re-render). Animar solo `transform`.

### Hover

- `.nv` (nav, botones): `filter:brightness(1.15)`.
- `.pin` (pines del mapa): `translateY(-3px) scale(1.03)`, `transition:transform .15s ease`.
- `.arw` (flechas y pastillas del atelier): fondo `rgba(255,255,255,.1)`, borde `rgba(255,255,255,.4)`.
- `.scard` (tarjetas de tienda): borde `rgba(155,107,255,.4)`, `translateY(-2px)`, `transition:all .18s ease`.
- Botones primarios: `translateY(-2px)`.

### Scrollbars personalizadas

`width:9px`, thumb `rgba(155,107,255,.4)`, `border-radius:9px`.

---

## State Management

Todo el estado vive en un único componente en el prototipo. En producción conviene dividirlo
(sesión/economía global; UI local por pantalla).

### Estado global (usuario y economía)

| Variable | Tipo | Inicial | Notas |
|---|---|---|---|
| `screen` | string | `'login'` | Router del prototipo. En producción: rutas reales. |
| `coins` | number | `48500` | **Wones (₩)**. |
| `gems` | number | `320` | Moneda premium. |
| `xp` | number | `2780` | |
| `xpMax` | number | `4200` | |
| `level` | number | `14` | |
| `owned` | string[] | `['beanie','glasses','korea','hoodie','hello','cat']` | Ids de artículos comprados. |
| `following` | string[] | `['jihoon']` | Ids de profesores seguidos. |
| `reserved` | string[] | `[]` | Ids de clases reservadas. |

### Estado de UI por pantalla

| Variable | Inicial | Pantalla |
|---|---|---|
| `showPw` | `false` | Login (visibilidad de la contraseña) |
| `parts` | `{pelo:1, expresion:0, torso:0, piernas:1, calzado:1, sombrero:1, accesorios:1, mochila:1, companero:1}` | Avatar (índice por parte) |
| `storeTab` | `'destacados'` | Tienda |
| `vfilter` | `'all'` | Vocabulario |
| `mtab` | `'diarias'` | Misiones |
| `claimedM` | `[]` | Misiones (ids reclamadas) |
| `liveFilter` | `'hoy'` | Clases en vivo |
| `activeTeacher` | `'jihoon'` | Perfil de profesor |
| `activeClass` | `'e1'` | Sala en vivo |
| `booking` | `null` | Modal (id del profesor o `null`) |
| `bookDay` | `0` | Modal (índice de día) |
| `bookSlot` | `null` | Modal (índice de horario) |
| `chat` | `[]` | Sala en vivo (mensajes) |
| `chatDraft` | `''` | Sala en vivo (input) |
| `lessonStep` | `0` | Lección (índice de pregunta; `>= total` = completada) |
| `choice` | `null` | Lección (opción elegida) |
| `checked` | `false` | Lección (¿ya comprobó?) |
| `correct` | `0` | Lección (aciertos) |
| `rewardGiven` | `false` | Lección (evita recompensa doble) |
| `toast` | `null` | Global |
| `hudOverride` | `null` | Variante de estilo A/B |

### Transiciones clave

- **Comprar** → validar propiedad, luego saldo; descontar y añadir a `owned`; toast.
- **Reclamar misión** → si no está en `claimedM`: añadir id, sumar wones, toast.
- **Lección** → elegir opción → comprobar (`checked=true`, suma acierto) → continuar
  (`lessonStep+1`, resetear `choice` y `checked`) → al terminar, pantalla de fin →
  "VOLVER AL MAPA" otorga la recompensa **solo si `rewardGiven` es falso**.
- **Reservar 1:1** → validar horario y gemas → descontar, cerrar modal, toast.
- **Unirse a clase** → fija `activeClass`, siembra los 3 mensajes iniciales, navega a la sala.

### Data fetching (producción)

Endpoints sugeridos: perfil y economía del usuario · catálogo de la tienda · catálogo de partes del
avatar y look guardado · profesores (lista y detalle con reseñas) · clases (agenda, reservas,
token de sala) · misiones y progreso · vocabulario. Las compras, reservas y reclamos de recompensa
deben validarse **en el servidor**; el cliente solo refleja el resultado.

---

## Assets

Todos están en la carpeta `assets/` de este paquete.

| Archivo | Origen | Uso |
|---|---|---|
| `seoul-map-v3.png` | Recorte del mapa pixel-art del usuario | **Marcador de posición del canvas de three.js** en la pantalla del mapa. 1100×667. Trae los nombres de los lugares pintados. |
| `seoul-scene.png` | Mockup de referencia del usuario | Hero del login, vista previa del avatar y fondos atenuados de las demás pantallas. |
| `bogota-scene.png` | Mockup de referencia del usuario | Miniatura de la ciudad bloqueada. |
| `capy.png` | Recorte del mockup de referencia | Mascota capibara: avatar, personaje, PIP de la sala. |
| `item-beanie.png` · `item-bucket.png` · `item-frog.png` · `item-hat.png` | Recortes del mockup | Sombreros. |
| `item-glasses.png` · `item-headphones.png` · `item-mask.png` · `item-camera.png` | Recortes del mockup | Accesorios. |
| `item-korea.png` · `item-army.png` · `item-school.png` · `item-bear.png` | Recortes del mockup | Mochilas. |

**Importante**: estos archivos son **recortes de mockups de referencia**, no assets de producción.
Reemplazarlos por los assets definitivos (o por el render real de three.js). Los íconos de ítems
tienen fondo opaco, no transparente.

**Iconografía**: todos los íconos de UI son **SVG inline** de trazo (`stroke-width:2`,
`stroke-linecap:round`, `stroke-linejoin:round`, estilo Lucide/Feather). En producción, usar la
librería de íconos del codebase. Los logos sociales (Google, Apple, Discord, Instagram, Twitter)
también son SVG inline.

**Emoji**: se usan como iconografía de contenido (misiones, lugares, potenciadores, compañeros,
banderas). Si el codebase tiene una política contra emoji en UI, sustituirlos por ilustraciones.

**Moneda**: la ficha de wones es un SVG (círculo `#4fb3a8` con borde `#2f8378` y el glifo ₩ en
`#06231f`); la gema es un rombo (`#a87bff` con faceta `#d3bcff`). Conviene extraerlos como
componentes `<WonCoin/>` y `<Gem/>`.

---

## Variantes de estilo (A / B)

El prototipo incluye un toggle **A/B** en la barra superior que cambia el tratamiento de los botones
primarios y del dock del mapa. Sirvió para elegir dirección visual; **en producción conviene fijar una**.

| | A (glossy) | B (plano) |
|---|---|---|
| Fondo del botón primario | `linear-gradient(135deg,#9b6bff,#7c3aed)` | `#7c3aed` |
| Borde | ninguno | `2px solid #c4a6ff` |
| Radio | `14px` | `9px` |
| Sombra | `0 12px 26px rgba(124,58,237,.5), inset 0 1px 0 rgba(255,255,255,.3)` | `0 4px 0 #5a23b3` (sólida) |
| Tipografía de la etiqueta | Baloo 2 700, 17px, `letter-spacing:.3px` | Baloo 2 700, 16px, `uppercase`, `letter-spacing:1px` |
| Botón del dock | `border-radius:18px`, fondo `rgba(12,18,34,.86)`, borde hairline, sombra | `border-radius:10px`, fondo `#11192b`, borde `2px solid #2a3654`, sin sombra |

El usuario está probando la variante **B** en su vista.

---

## Files

| Archivo | Qué es |
|---|---|
| `Cappilingua.dc.html` | **Fuente del prototipo.** Runtime propietario de prototipado; leer como especificación (la clase `Component` tiene datos y lógica; el template, estructura y estilos). |
| `Cappilingua - Prototipo.html` | Versión **autocontenida** (imágenes embebidas). Abrir en el navegador para ver el diseño funcionando. Referencia visual viva. |
| `assets/` | Imágenes usadas por el prototipo. |

### Cómo leer `Cappilingua.dc.html`

- `<sc-for list="{{ items }}" as="it">` = `items.map(it => …)`.
- `<sc-if value="{{ flag }}">` = render condicional.
- `{{ path }}` = valor expuesto por `renderVals()` en la clase `Component`.
- `renderVals()` devuelve todo lo que el template consume: valores planos, arrays ya calculados,
  objetos de estilo y handlers. **Ahí está la lógica de presentación** (qué estilo aplica a cada
  estado, qué etiqueta lleva cada botón, cómo se filtra cada lista).
- Los métodos `TEACHERS()`, `EVENTS()`, `MISSIONS()`, `QUESTIONS()`, `STORE_ITEMS()`, `PARTS()`,
  `VOCAB()`, `REVIEWS()` contienen los **datos de ejemplo** — replicarlos como fixtures o semillas.
- `style-hover`, `style-active`, `style-focus` son pseudo-estados del runtime; traducirlos a
  `:hover`, `:active`, `:focus` reales.

---

## Notas de implementación

1. **El escalado con `transform: scale()` es un artificio del prototipo** para encajar 1440×900 en
   cualquier viewport. En producción, hacer layout responsive real (la barra superior y la lateral
   se colapsan; las grillas de 3–4 columnas bajan a 2 y 1).
2. **three.js**: el mapa de la ciudad (pantalla 11) y la vista previa del personaje (pantalla 9) son
   los dos canvas. Los pines del mapa están posicionados en porcentajes sobre la imagen; con la escena
   real conviene proyectar posiciones 3D a coordenadas de pantalla, o mantener los pines como overlay
   HTML anclado a puntos conocidos.
3. **El panel de personalización debe reflejarse en el modelo 3D**: cada fila corresponde a una malla
   o material intercambiable. Definir la convención de nombres de las mallas antes de implementar.
4. **Accesibilidad**: el prototipo no la cubre. Añadir `aria-label` a los botones de solo ícono
   (flechas, controles de la sala, audio del vocabulario), foco visible, navegación por teclado en las
   filas del atelier (flechas izquierda/derecha), roles y `aria-live` para el toast, y verificar
   contraste del texto atenuado (`#7a8298` sobre `#0b1120` está al límite en tamaños pequeños).
5. **Textos en español rioplatense/neutro mezclado**: el panel usa "Personalizá"/"Ajustá"/"Gastá" (voseo)
   mientras el resto usa tuteo ("Explora", "Completa"). Unificar según el mercado objetivo.
6. **Internacionalización**: hay coreano (한국어) mezclado con español en la UI de contenido. Externalizar
   los textos y no concatenar cadenas para los toasts.
7. **Formato de moneda**: los wones se muestran con `toLocaleString('es-CO')` (separador de miles con
   punto: `₩48.500`). El won no usa decimales.
